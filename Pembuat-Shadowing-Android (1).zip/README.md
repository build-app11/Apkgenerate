# Learning Fun (Android)

Aplikasi pembungkus (WebView) untuk https://learningfun.zone.id
Isi aplikasi selalu mengikuti website. Perubahan di website langsung tampil,
tanpa pasang ulang APK. Tanpa koneksi, tampil halaman offline dengan tombol "Coba lagi".

APK dibangun otomatis oleh GitHub Actions (lihat .github/workflows/build.yml).
Pasang ulang APK hanya perlu jika kode aplikasi diubah (ikon, nama, alamat website).
Alamat website ada di MainActivity.java (SITE dan SITE_HOST).
