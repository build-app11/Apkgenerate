# Pembuat Shadowing (Android)

Aplikasi Android yang membungkus halaman "Pembuat Shadowing" (WebView).
Tidak perlu Android Studio: APK dibangun otomatis oleh GitHub Actions.

## Cara mendapatkan APK

1. Buat repositori baru di GitHub (kosong, boleh privat).
2. Unggah SELURUH isi folder ini ke repositori itu, termasuk folder `.github`.
   - Lewat komputer: `git init`, `git add .`, `git commit -m "awal"`,
     `git remote add origin <url-repo>`, `git push -u origin main`.
   - Lewat web GitHub: "Add file > Upload files", tarik semua folder.
     Jika folder `.github` tidak ikut terunggah, pakai "Add file > Create new file",
     ketik nama `.github/workflows/build.yml`, lalu salin isi file itu.
3. Buka tab **Actions**. Workflow "Build APK" jalan otomatis (sekitar 3-6 menit).
   Kalau tidak jalan, pilih "Build APK" lalu "Run workflow".
4. Setelah hijau, buka tab **Releases** (kolom kanan halaman repo), lalu
   unduh `app-debug.apk` dari HP. Buka file itu dan izinkan
   "Pasang dari sumber ini" jika diminta.

## Catatan
- Tombol **Unduh** membuka pemilih lokasi Android untuk menyimpan file .html.
- Tombol **Kembali** di HP menutup preview / layar penuh video.
- Ubah tampilan atau fitur dengan mengedit `app/src/main/assets/index.html`,
  lalu unggah ulang; APK baru dibangun otomatis.
- APK ini bertanda tangan debug: cukup untuk dipasang sendiri, bukan untuk Play Store.
